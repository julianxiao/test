angular.module('SettingsService', []).factory('Settings', ['$http', function($http) {

	

}]);