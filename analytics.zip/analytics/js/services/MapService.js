angular.module('MapService', []).factory('Map', ['$http', function($http) {

	

}]);