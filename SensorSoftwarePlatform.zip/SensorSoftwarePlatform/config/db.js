module.exports = {
	url : 'mongodb://localhost/analytics',
	urlLab : 'mongodb://xively:eegl.mmm@ds043329.mongolab.com:43329/xively'
}