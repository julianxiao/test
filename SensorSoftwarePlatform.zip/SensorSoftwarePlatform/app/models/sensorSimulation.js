

var User = function() {
  this.name = "name";
  this.email = "email";
};
module.exports = User;
