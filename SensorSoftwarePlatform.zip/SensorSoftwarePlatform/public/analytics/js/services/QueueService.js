angular.module('QueueService', []).factory('Queue', ['$http', function($http) {

	

}]);