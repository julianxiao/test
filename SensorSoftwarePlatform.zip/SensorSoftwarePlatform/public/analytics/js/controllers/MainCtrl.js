angular.module('MainCtrl', []).controller('MainController', function($scope) {

	$scope.tagline = 'All you can eat!';	

});