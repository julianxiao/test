angular.module('SettingsCtrl', []).controller('SettingsController', function($scope) {

	$scope.tagline = 'To be, or not to be, that is the question!';

});