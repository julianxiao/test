package com.example.a30krzz.accesscontrol;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class MainActivity extends ActionBarActivity {

    private NfcAdapter mAdapter;
    private PendingIntent mPendingIntent;
    private String[][] mTechLists;
    TextView urlText;
    Spinner companyName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            showSettings();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showSettings() {
        urlText = (TextView) findViewById(R.id.editText4);
        companyName = (Spinner) findViewById(R.id.spinner);
        if(urlText.getVisibility() == View.VISIBLE )
        {
            urlText.setVisibility(View.INVISIBLE);
            companyName.setVisibility(View.INVISIBLE);
        }
        else {
            urlText.setVisibility(View.VISIBLE);
            companyName.setVisibility(View.VISIBLE);

        }

    }

    protected void serverRequest()
    {
        //String username = getString(R.string.username);
        String username = ((DataDevice) this.getApplication()).getUsername();
        String usernameQuery = null;
        try {
            usernameQuery = URLEncoder.encode(username, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String password = ((DataDevice) this.getApplication()).getPassword();
        String passwordQuery = null;
        try {
            passwordQuery = URLEncoder.encode(password, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String urlBase = ((DataDevice) this.getApplication()).getServerURL();

        DataDevice dataDevice = (DataDevice)getApplication();

        String id = dataDevice.getUid();
        String url = urlBase + "/api/login" + "?username=" + usernameQuery + "&password=" + passwordQuery;

        RequestQueue queue = Volley.newRequestQueue(this);

        final TextView mTxtDisplay= (TextView) findViewById(R.id.textView4);
        // Instantiate the RequestQueue.

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        mTxtDisplay.setText("");
                        Intent intent = new Intent(MainActivity.this, LoginActivity.class );
                        startActivity(intent);

                        //mTxtDisplay.setText("Response: " + response.toString());
                        //new StartWriteTask().execute();
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volly Error", error.toString());
                        mTxtDisplay.setText(error.toString());
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                            Toast.makeText(getApplicationContext(),
                                    "error_network_timeout",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof AuthFailureError) {
                            //TODO
                        } else if (error instanceof ServerError) {
                            //TODO
                        } else if (error instanceof NetworkError) {
                            //TODO
                        } else if (error instanceof ParseError) {
                            //TODO
                        }
                    }
                });

// Access the RequestQueue through your singleton class.
        queue.add(jsObjRequest);

    }

    public void starMainScreen(View view)
    {

        EditText value1 = (EditText) findViewById(R.id.editText);
        String username = value1.getText().toString();
        EditText valuePassword = (EditText) findViewById(R.id.editText3);
        String password = valuePassword.getText().toString();
        EditText value2 = (EditText) findViewById(R.id.editText4);
        String serverAddress = value2.getText().toString();
        ((DataDevice) this.getApplication()).setUsername(username);
        ((DataDevice) this.getApplication()).setPassword(password);
        ((DataDevice) this.getApplication()).setServerURL(serverAddress);

        serverRequest();


    }


}
