
## Demo video

A walkthrough video demo can be accessed at https://dl.dropboxusercontent.com/u/5773213/IMG_1472.MOV


##Server

Copy the folder of the server code to your machine (windows or mac). Install [Node.js](http://nodejs.org/) on the machine. After installation, open a command prompt window, go to the directory and type 

```sh
node index.js
```

The server app should now be running on the machine at [localhost:3000](http://localhost:3000/). Check the IP address of the machine and write it down. You will need to enter the IP address at the phone app. Please make sure that the phone and the server are in the same network.

![](http://localhost:3000/help/phone1.png)

If you have trouble setting up a local server, you can also use a deployment of the server on the cloud at 
https://fast-basin-3771.herokuapp.com 
![](http://localhost:3000/help/server1.png)
Please note that in this case, you don't need to add port number 3000.

## Web application
Open a browser (try Chrome) and go to the server address at port 3000. The first page shows a sample log of check in/out events (the above image).

Click on the cabinets link. This is the page you will get the door open alert.
![](http://localhost:3000/help/server2.png)

Please note that the buttons on the pages are place holders for demo purposes only.

## Phone app
After you log in (the user name and password are not checked), you will see the app has two basic functions, check-in and check-out. Tap the check-in button to open the door and tap the check-out button to lock the door again. These check-in and check-out events will be logged at the server and displayed on the web page.

## Help

If you have any trouble making the system work, please contact jxiao@mmm.com

