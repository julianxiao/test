var jsonServer = require('json-server');

var server = jsonServer.create();

server.use(jsonServer.defaults);

var chance = require('chance');
var moment = require('moment');

var data = {
	logItems: [],
	cabinets: []
};

server.get('/api/log', function(req, res) {

	var logItem = {
		'id': data.logItems.length,
		'name': req.query.name,
		'timeStamp': moment(),
		'cabinetID': req.query.cabinetID,
		'action': req.query.action,
		'text': chance().sentence({
			words: 4
		})
	};
	data.logItems.push(logItem);

	var cabinetItem = data.cabinets[req.query.cabinetID - 1];

	if (req.query.action == 'check out') {


		cabinetItem.oldPassword = cabinetItem.newPassword;
		cabinetItem.newPassword = chance().integer({
			min: 10000000,
			max: 99999999
		});
		cabinetItem.warning = '';

		lastEvent.event = 'check out';
		lastEvent.reload = true;

		data.cabinets[req.query.cabinetID - 1] = cabinetItem;
	}

	if (req.query.action == 'check in') {

		cabinetItem.name = req.query.name;
		cabinetItem.openTime = moment();
		cabinetItem.warning = 'alert-warning';

		lastEvent.event = 'check in';
		lastEvent.reload = true;

		data.cabinets[req.query.cabinetID - 1] = cabinetItem;
	}
	res.json(logItem);
});

var lastEvent = {
	event: 'check out',
	reload: false
};



server.get('/api/getDoorStatus', function(req, res) {
	res.json(lastEvent);

	if (lastEvent.reload) {
		lastEvent.reload = false;
	}

});


server.get('/api/wait', function(req, res) {
	var stop = new Date().getTime();
	while (new Date().getTime() < stop + 2000) {;
	}

});

var fs = require('fs');


data = JSON.parse(fs.readFileSync('logItems_backup.json', 'utf8'));

server.use(jsonServer.router(data));

server.listen(3000, function() {
	console.log("server is up running!");
});