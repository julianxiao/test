package com.nfc.apps;

import android.app.Application;

/**
 * Created by a30krzz on 5/27/2015.
 */
public class myApplication extends Application {

    private String username;

    public String getSomeVariable() {
        return username;
    }

    public void setSomeVariable(String someVariable) {
        this.username = someVariable;
    }
}
